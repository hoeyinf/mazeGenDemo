// Header file for functions used in mazeGen.c

#ifndef MAZE_GEN_MAIN_FUNCTIONS_H
#define MAZE_GEN_MAIN_FUNCTIONS_H

#define EXIT_SUCCESS 0
#define EXIT_ARG_ERROR 1

#define MAZE_MIN 5
#define MAZE_MAX 100

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>


// FUNCTION DECALARATIONS


/* Checks that command line argument is used correctly

Outputs: usage message when incorrect
Returns: 1 if correct, 0 if incorrect
*/
int args_check(int num_args, char *args[]);

/* Populates an array width*height for the maze */
void initialize_maze(Maze *maze);

/* Maze generation algorithm

Updates: maze map*/
void generate_maze(Maze *maze);

/* Creates maze file */
void create_maze_file(Maze *maze, char *filename);


// FUNCTION DEFINITIONS


int args_check(int num_args, char *args[]){
  int width, height;

  // args length check
  if (num_args != 4)
  {
    printf("Correct usage: ./mazeGen <maze filename> <width> <height>\n");
    return 0;
  }

  // loops through width and height arguments, checking they are made of integers
  for (int i = 0; i < (int)strlen(args[2]); i++) {
    if (!isdigit(args[2][i])){
      printf("Maze width must be an integer\n");
      return 0;
    }
  }
  width = atoi(args[2]);
  
  for (int i = 0; i < (int)strlen(args[3]); i++) {
    if (!isdigit(args[3][i])){
      printf("Maze height must be an integer\n");
      return 0;
    }
  }
  height = atoi(args[3]);

  // checks that width and height are correct size
  if (width < MAZE_MIN || width > MAZE_MAX || height < MAZE_MIN || height > MAZE_MAX){
    printf("Maze width and height must both be between 5 and 100 (inclusive)\n");
    return 0;
  }

  return 1;
}

void initialize_maze(Maze *maze){

  // allocate memory for maze
  maze->map = (char*)malloc(maze->width * maze->height * sizeof(char)); 
  
  // initialize maze as a series of ' ' nodes separated by walls
  for (int y = 0; y < maze->height; y++){
    for (int x = 0; x < maze->width; x++){
      if (y % 2 == 1 && x % 2 == 1){
        maze->map[y * maze->width + x] = ' ';
      }else{
        maze->map[y * maze->width + x] = '#';
      }
    }
  }
}

void generate_maze(Maze *maze){

  // seeds random number generator
  // random number generation based on: https://www.javatpoint.com/random-function-in-c
  time_t t;
  srand (time (&t));

  // allocate memory to stack
  int maze_size = maze->width/2 * maze->height/2;
  Stack stack;
  stack.path = malloc(maze_size * sizeof(Coordinate));

  Coordinate start, current_cell, next_cell, end;
  int max = -1;

  /* Algorithm based on: https://en.wikipedia.org/wiki/Maze_generation_algorithm#Iterative_implementation_(with_stack)
  Uses a stack to perform a depth-first search to create a maze */
  
  // push initial start to stack, mark as visited
  stack.top = -1;
  start = random_coordinate(maze);
  maze->map[start.ycoor * maze->width + start.xcoor] = 'v';
  push(&stack, start);

  // while stack is not empty
  while (stack.top != -1){

    // pop element, set as current cell
    current_cell = pop(&stack);

    // checks which neighbors are unvisited, using array representing {W, A, S, D}
    int neighbors[4] = {1, 1, 1, 1};
    check_neighbors(maze, current_cell, neighbors);

    // if current cell has any unvisited neighbors
    if (neighbors[0] == 1 || neighbors[1] == 1 || neighbors[2] == 1 || neighbors[3] == 1){

      // push current cell back onto stack
      push(&stack, current_cell);

      // choose one of its unvisited neighbors
      next_cell = choose_neighbors(current_cell, neighbors);
      
      // remove wall between current cell and chosen neighbor
      remove_wall(maze, current_cell, next_cell);

      // mark chosen cell as visited, push it onto the stack
      maze->map[next_cell.ycoor * maze->width + next_cell.xcoor] = 'v';
      push(&stack, next_cell);
      
      // sets end point to be next cell if stack is currently at its largest
      if (stack.top > max){
        end = next_cell;
        max = stack.top;
      }
    }
  }
  free(stack.path);

  // set start and end points
  maze->map[start.ycoor * maze->width + start.xcoor] = 'S';
  maze->map[end.ycoor * maze->width + end.xcoor] = 'E';

  clean_map(maze);
  printf("Maze generated!\n");
}

void create_maze_file(Maze *maze, char *filename){

  FILE *file = fopen(filename, "w");

  // writes maze to file
  for (int y = 0; y < maze->height; y++){
    for (int x = 0; x < maze->width; x++){
      fprintf(file, "%c", maze->map[y * maze->width + x]);
    }
    fprintf(file, "\n");
  }

  fclose(file);
  printf("Maze put into %s successfully\n", filename);
}

#endif
