// Header file for typedef structs for maze generation

#ifndef MAZE_GEN_STRUCTS_H
#define MAZE_GEN_STRUCTS_H

// struct for a coordinate
// note: ycoor shown first, since arrays are [row][height]
typedef struct coordinate{
  int ycoor;
  int xcoor;
} Coordinate;

// struct for data of the maze being played
typedef struct maze{
  int height;
  int width;
  char *map;
  Coordinate start;
  Coordinate end;
  Coordinate player;
} Maze;

// struct for a stack of Coordinates
typedef struct stack{
  int top;
  Coordinate* path;
} Stack;

#endif