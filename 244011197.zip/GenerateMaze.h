// Header file for functions used in generate_maze()

#ifndef GENERATE_MAZE_H
#define GENERATE_MAZE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


// FUNCTION DECLARATIONS

/* Generates a random coordinate on given maze that is a valid cell */
Coordinate random_coordinate(Maze *maze);

/* Checks which neighbors of the cell have not been visited

Updates: array of 4 ints, each int representing {W, A, S, D} respectively;
1 = unvisited, 0 = visited*/
void check_neighbors(Maze *maze, Coordinate cell, int *neighbors);

/* Chooses one of the unvisited neighbors of the current cell */
Coordinate choose_neighbors(Coordinate current, int neighbors[]);

/* Removes wall '#' between current and next cells

Updates: maze map*/
void remove_wall(Maze *maze, Coordinate current, Coordinate next);

/* Changes all visited 'v' cells in the maze map back to ' '*/
void clean_map(Maze *maze);


// FUNCTION DEFINITIONS


Coordinate random_coordinate(Maze *maze){

  Coordinate random;

  // generates valid random coordinates (odd numbers only)
  // assumes that srand() has already been used before the function was called
  random.ycoor = ((rand() % (maze->height-2)) / 2) * 2 + 1;
  random.xcoor = ((rand() % (maze->width-2)) / 2) * 2 + 1;
  
  return random;
}

void check_neighbors(Maze *maze, Coordinate cell, int *neighbors){

  int W = cell.ycoor - 2;
  int A = cell.xcoor - 2;
  int S = cell.ycoor + 2;
  int D = cell.xcoor + 2;

  // checks if neighbors are out of bounds/visited, updates to 0 if they are
  if (W < 0 || maze->map[W * maze->width + cell.xcoor] == 'v'){
    neighbors[0] = 0;
  }
  if (A < 0 || maze->map[cell.ycoor * maze->width + A] == 'v'){
    neighbors[1] = 0;
  }
  if (S > maze->height-1 || maze->map[S * maze->width + cell.xcoor] == 'v'){
    neighbors[2] = 0;
  }
  if (D > maze->width-1 || maze->map[cell.ycoor * maze->width + D] == 'v'){
    neighbors[3] = 0;
  }
}

Coordinate choose_neighbors(Coordinate current, int neighbors[]){

  Coordinate chosen_cell;

  // rolls random neighbors until a valid unvisited neighbor is rolled
  // assumes that srand() has already been used before the function was called
  int direction = rand() % 4;
  while (neighbors[direction] == 0){
    direction = rand() % 4;
  }

  // sets coordinates of chosen neighbor
  switch (direction)
  {
  case 0:
    chosen_cell.ycoor = current.ycoor - 2;
    chosen_cell.xcoor = current.xcoor;
    break;
  case 1:
    chosen_cell.ycoor = current.ycoor;
    chosen_cell.xcoor = current.xcoor - 2;
    break;
  case 2:
    chosen_cell.ycoor = current.ycoor + 2;
    chosen_cell.xcoor = current.xcoor;
    break;
  case 3:
    chosen_cell.ycoor = current.ycoor;
    chosen_cell.xcoor = current.xcoor + 2;
    break;
  }

  return chosen_cell;
}

void remove_wall(Maze *maze, Coordinate current, Coordinate next){

  // finds coordinates of wall by averaging current and next coordinates
  Coordinate wall;
  wall.ycoor = (current.ycoor + next.ycoor) / 2;
  wall.xcoor = (current.xcoor + next.xcoor) / 2;

  // remove wall
  maze->map[wall.ycoor * maze->width + wall.xcoor] = ' ';

}

void clean_map(Maze *maze){

  // loops through the maze, changes any 'v's into ' 's
  for (int y = 0; y < maze->height; y++){
    for (int x = 0; x < maze->width; x++){
      if (maze->map[y * maze->width + x] == 'v'){
        maze->map[y * maze->width + x] = ' ';
      }
    }
  }
}

#endif