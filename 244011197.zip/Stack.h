// Header file for stack functions for Coordinate

#ifndef STACK_H
#define STACK_H

#include <stdio.h>
#include <stdlib.h>

#define EXIT_PATH_ERROR 124

// FUNCTION DECLARATIONS


void push(Stack *stack, Coordinate space);
Coordinate pop(Stack *stack);


// FUNCTION DEFINITIONS


void push(Stack *stack, Coordinate space){

  // makes sure path doesn't somehow go over maximum path size
  if (stack->top > 50 * 50){
    printf("Overloading stack!\n");
    exit(EXIT_PATH_ERROR);
  }

  stack->top += 1;
  stack->path[stack->top] = space;
}

Coordinate pop(Stack *stack){

  // makes sure empty stack can't be emptier
  if (stack->top == -1){
    printf("Popping empty stack!\n");
    exit(EXIT_PATH_ERROR);
  }
  
  Coordinate popped = stack->path[stack->top];
  stack->top -= 1;
  return popped;
}

#endif