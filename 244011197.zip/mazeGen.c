#include "MazeGenStructs.h"
#include "Stack.h"
#include "GenerateMaze.h"
#include "MazeGenMainFunctions.h"

Maze maze;

int main(int argc, char *argv[]){

  // command line check; sets height and width if correct
  if (args_check(argc, argv) == 0){
    exit(EXIT_ARG_ERROR);
  }
  maze.width = atoi(argv[2]);
  maze.height = atoi(argv[3]);

  initialize_maze(&maze);
  generate_maze(&maze);

  create_maze_file(&maze, argv[1]);

  free(maze.map);
  exit(EXIT_SUCCESS);
}